import sqlite3
from tabulate import tabulate

def print_all_folder():
    conn = sqlite3.connect('userdata.db')
    c = conn.cursor()

    c.execute("SELECT keyword, shortcut FROM folder_data")
    user = c.fetchall()

    col_names = ["Keywords", "Folder Location"]
    print(tabulate(user, headers=col_names, tablefmt="fancy_grid"))


