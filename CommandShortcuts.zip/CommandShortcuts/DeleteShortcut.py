import sqlite3
from tabulate import tabulate

def delete(keyword):
    conn = sqlite3.connect('userdata.db')
    c = conn.cursor()

    c.execute("DELETE FROM folder_data WHERE keyword='{}'".format(keyword))

    c.execute("SELECT keyword, shortcut FROM folder_data")
    user = c.fetchall()

    col_names = ["Keywords", "Folder Location"]
    print(tabulate(user, headers=col_names, tablefmt="fancy_grid"))

    conn.commit()
    conn.close()