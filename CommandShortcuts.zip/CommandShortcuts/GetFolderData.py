import sqlite3

def get_folder_location(keyword):
    conn = sqlite3.connect('userdata.db')
    c = conn.cursor()

    c.execute("SELECT shortcut FROM folder_data WHERE keyword='{}'".format(keyword))
    folder_loc = c.fetchone()

    conn.commit()
    conn.close()
    return folder_loc[0]

