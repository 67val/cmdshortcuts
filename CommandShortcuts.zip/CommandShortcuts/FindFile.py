import os
import subprocess


def find(files, file_location, type):
    file = file_location  # replace with your downloads directory, double backslash is required.
    # name_of_file = input("Find file in downloads (file name): ")

    result = []

    if type.lower().__eq__("file"):
        for dirpath, subdirs, filess in os.walk(file):
            for i in filess:

                if files.__eq__(i) or files.lower() in i.lower():
                    f = os.path.join(dirpath, i)
                    result.append(f)

    elif type.lower().__eq__("dir"):
        for dirpath, subdirs, filess in os.walk(file):
            for i in subdirs:

                if files.__eq__(i) or files.lower() in i.lower():
                    f = os.path.join(dirpath, i)
                    result.append(f)
    else:
        print("Type file/dir, '{}' is not recognized.")
    # Print results, print not found if it cannot find the name
    if len(result) == 0:  # if the result is empty, it will print not found.
        print("not found")
    elif len(result) > 0:  # if there are more than 1 results, print all of them with indexes
        for i in result:
            print(str(result.index(i) + 1) + " " + str(i))

        try:
            open_index = int(input("Open Index: "))
            if os.path.isfile(result[open_index - 1]):  # Check if file is a directory or a file
                subprocess.call(result[open_index - 1], shell=True)
            else:
                os.startfile(result[open_index - 1])
        except IndexError as e:
            print("There are only ({}) results.".format(len(result)))
        except ValueError as e:
            print("Only type the index(number) of the file you are looking for.")

