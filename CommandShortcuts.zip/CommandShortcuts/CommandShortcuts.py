import HelpList as helplist
import InsertDataDB as data_insert
import os
import GetFolderData as folder_data
import SearchFIle as s
import PrintShortcuts as shortcuts
import FindFile as find_file
import DeleteShortcut as d

print("Type 'help' to show the list of commands, replace spaces with an underscore '_'.")
# Everything in this python file is to recognize and execute the commands typed by the user.
while True:
    user_command = input("Type command: ")

    inputs = user_command.split(" ")
    try:
        if inputs[0].lower().__eq__("help"):  # Help conditions
            helplist.command_list()

        # CREATE COMMANDS
        elif inputs[0].lower().__eq__("create") and inputs[1].lower().__eq__("folder"):  # Create shortcut conditions

            exist = os.path.exists(inputs[3])
            data_insert.insert(inputs[2], inputs[3])

        elif inputs[0].lower().__eq__("exit"):  # Exit conditions
            break

        elif inputs[0].lower().__eq__("search"):  # File search condition
            folder_location = folder_data.get_folder_location(inputs[1])
            if '_' in inputs[2]:

                s.search(inputs[2].replace('_', ' '), folder_location)

            else:
                s.search(inputs[2], folder_location)

        # LIST COMMANDS
        elif inputs[0].lower().__eq__("list") and inputs[1].lower().__eq__("folder"):
            shortcuts.print_all_folder()

        # Find files in a directory inside a directory
        elif inputs[0].lower().__eq__("find"):
            folder_location = folder_data.get_folder_location(inputs[1])
            if '_' in inputs[2]:
                find_file.find(inputs[2].replace('_', ' '), folder_location, inputs[3])
            else:
                find_file.find(inputs[2], folder_location, inputs[3])
        # DELETE SHORTCUTS
        elif inputs[0].lower().__eq__("delete"):
            d.delete(inputs[1])

        else:
            print("Invalid command, Type 'help' to show the list of commands.")
# Exception
    except IndexError as e:
        print("Incomplete command, type 'help' to see the proper syntax.")







