import sqlite3

def insert(keyword, shortcut):
    conn = sqlite3.connect('userdata.db')
    c = conn.cursor()

    print(keyword)
    print(shortcut)
    c.execute("INSERT INTO folder_data (keyword,shortcut) VALUES('{}','{}')".format(keyword, shortcut))
    # c.execute("SELECT * FROM folder_data")
    # data = c.fetchall()
    # print(data)

    conn.commit()
    conn.close()

