import sqlite3

conn = sqlite3.connect('userdata.db')

c = conn.cursor()

#c.execute("""CREATE TABLE folder_data(
#        key INTEGER PRIMARY KEY AUTOINCREMENT,
#        keyword VARCHAR,
#        shortcut VARCHAR
#        )""")

c.execute("DELETE FROM folder_data")


conn.commit()
conn.close()