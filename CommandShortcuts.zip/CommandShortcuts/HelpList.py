# This module contains the list of commands and will print upon call.

def command_list():
    print("============================================================================")
    print("help - shows list of commands")
    print("search (folder) (file name) - searches for the filename in the folder")
    print("create folder (shortcut name) (directory) - creates a shortcut ")
    print("exit - exits the file")
    print('list (folder/url) - lists all shortcuts')
    print('delete (shortcut_name - deletes the shortcut')
    print("find (shortcut name) (filename) (dir/file) - searches for a file name in multiple directories")
    print("============================================================================")